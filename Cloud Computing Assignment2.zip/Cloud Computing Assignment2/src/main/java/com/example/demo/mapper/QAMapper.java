package com.example.demo.mapper;

import com.baomidou.mybatisplus.mapper.BaseMapper;
import com.example.demo.entity.QA;

import java.util.List;

public interface QAMapper extends BaseMapper<QA> {
    public List<QA> select(QA question);

}
