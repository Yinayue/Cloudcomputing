package com.example.demo.Controller;

import com.alibaba.fastjson.JSONObject;
import com.example.demo.Service.IQAService;
import com.example.demo.entity.QA;
import com.example.demo.util.WolframAlpha2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class QuestionController {

    @Autowired
    IQAService IQAService;


    //this is method for task1
//    @RequestMapping(value = "/ask",method = RequestMethod.GET)
//    @ResponseBody
//    public Object ask(String question){
//        JSONObject result = new JSONObject();
//        try {
//            String answer = WolframAlpha2.query(question);
//            result.put("code", 200);
//            result.put("msg", "success");
//            result.put("data", answer);
//            return result;
//        }catch (Exception e){
//            e.printStackTrace();
//            result.put("code",400);
//            result.put("msg","error");
//            return result;
//        }
//    }



    //this is method for task 5
    @RequestMapping(value = "/ask",method = RequestMethod.GET)
    @ResponseBody
    public Object ask(String question){
        JSONObject result = new JSONObject();
        try {
            List<QA> stored = IQAService.select(question);

            if (stored.size() == 0) {
                String answer = WolframAlpha2.query(question);
                QA qa = new QA();
                qa.setAnswer(answer);
                qa.setQuestion(question);
                IQAService.insert(qa);
                result.put("code", 200);
                result.put("msg", "success");
                result.put("data", answer);
                return result;
            } else {
                QA qa = stored.get(0);
                result.put("code", 200);
                result.put("msg", "success");
                String temp = "<h3>The answer is from database</h3>";
                result.put("data", temp + qa.getAnswer());
                return result;
            }
        }catch (Exception e){
            e.printStackTrace();
            result.put("code",400);
            result.put("msg","error");
            return result;
        }
    }
}
