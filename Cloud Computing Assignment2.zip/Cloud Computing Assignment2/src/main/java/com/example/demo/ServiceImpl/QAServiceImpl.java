package com.example.demo.ServiceImpl;

import com.example.demo.Service.IQAService;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.example.demo.mapper.QAMapper;
import com.example.demo.entity.QA;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QAServiceImpl extends ServiceImpl<QAMapper, QA> implements IQAService {

    @Autowired
    QAMapper qaMapper;

    @Override
    public List<QA> select(String question) {
        QA qa = new QA();
        qa.setQuestion(question);
        return qaMapper.select(qa);
    }


}
