package com.example.demo.Service;

import com.baomidou.mybatisplus.service.IService;
import com.example.demo.entity.QA;

import java.util.List;

public interface IQAService extends IService<QA> {
    public List<QA> select(String question);
}
